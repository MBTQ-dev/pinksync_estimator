/**
 * OpenAI Embeddings Service
 * Handles vector embeddings generation using OpenAI models.
 */

import OpenAI from 'openai';

// Initialize OpenAI client
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

export interface EmbeddingOptions {
  model?: string;
  dimensions?: number;
}

const defaultOptions: EmbeddingOptions = {
  model: 'text-embedding-3-small', // Latest embeddings model
  dimensions: 1536, // Default dimension size for text-embedding-3-small
};

/**
 * Embeddings service
 */
export const embeddingService = {
  /**
   * Generate embeddings for text
   * @param text Text to generate embeddings for
   * @param options Options for embedding generation
   * @returns Array of embedding vectors
   */
  async generateEmbedding(
    text: string,
    options: EmbeddingOptions = {}
  ): Promise<number[]> {
    try {
      const mergedOptions = { ...defaultOptions, ...options };
      
      const response = await openai.embeddings.create({
        model: mergedOptions.model!,
        input: text,
        dimensions: mergedOptions.dimensions,
      });
      
      return response.data[0].embedding;
    } catch (error) {
      console.error('Error generating embedding:', error);
      throw error;
    }
  },
  
  /**
   * Generate embeddings for multiple texts
   * @param texts Array of texts to generate embeddings for
   * @param options Options for embedding generation
   * @returns Array of embedding vectors
   */
  async generateEmbeddings(
    texts: string[],
    options: EmbeddingOptions = {}
  ): Promise<number[][]> {
    try {
      const mergedOptions = { ...defaultOptions, ...options };
      
      const response = await openai.embeddings.create({
        model: mergedOptions.model!,
        input: texts,
        dimensions: mergedOptions.dimensions,
      });
      
      return response.data.map(item => item.embedding);
    } catch (error) {
      console.error('Error generating embeddings:', error);
      throw error;
    }
  },
  
  /**
   * Calculate similarity between two embeddings
   * @param embedding1 First embedding vector
   * @param embedding2 Second embedding vector
   * @returns Cosine similarity score (0-1)
   */
  calculateSimilarity(embedding1: number[], embedding2: number[]): number {
    // Cosine similarity implementation
    if (embedding1.length !== embedding2.length) {
      throw new Error('Embeddings must have the same dimensions');
    }
    
    let dotProduct = 0;
    let magnitude1 = 0;
    let magnitude2 = 0;
    
    for (let i = 0; i < embedding1.length; i++) {
      dotProduct += embedding1[i] * embedding2[i];
      magnitude1 += embedding1[i] * embedding1[i];
      magnitude2 += embedding2[i] * embedding2[i];
    }
    
    magnitude1 = Math.sqrt(magnitude1);
    magnitude2 = Math.sqrt(magnitude2);
    
    if (magnitude1 === 0 || magnitude2 === 0) {
      return 0;
    }
    
    return dotProduct / (magnitude1 * magnitude2);
  },
};

export default embeddingService;